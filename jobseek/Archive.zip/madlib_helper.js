'use strict';
module.change_code = 1;
var _ = require('lodash');

function MadlibHelper (obj) {
  this.started = false;
  this.madlibIndex = 0;
  this.currentStep = 0;
  this.madlibs = [
    {
      title: 'Your Resume',
      template: 'Your Name is ${firstname} ${lastname}. Your email address is ${email}. The latest education you obtained was a ${degree_obtained} from ${latest_school} completed in ${graduation_year}.',
      // template: 'Your Name is ${firstname} ${lastname}. The latest education you obtained was a ${degree_obtained} from ${latest_school} in ${graduation_year}. ',
      steps: [
        {
          value: null,
          template_key: 'firstname',
          prompt: 'your first name',
          help: 'Speak an adjective to add it to the madlib. An adjective is a word that modifies a noun (or pronoun) to make it more specific: a rotten egg, a cloudy day, or a tall, cool glass of water. What adjective would you like?'
        },
        {
          value: null,
          template_key: 'lastname',
          prompt: 'your last name',
          help: 'Speak an adjective to add it to the madlib. An adjective is a word that modifies a noun (or pronoun) to make it more specific: a rotten egg, a cloudy day, or a tall, cool glass of water. What adjective would you like?'
        },
        {
          value: null,
          template_key: 'email',
          prompt: 'your email address',
          help: 'Speak a type of bird to add it to the madlib. What type of bird would you like?',
        },
        {
          value: null,
          template_key: 'latest_school',
          prompt: 'the last school you attended',
          help: 'Speak a name of a room in a house. What room in a house would you like?',
        },
        {
          value: null,
          template_key: 'degree_obtained',
          prompt: 'degree obtained',
          help: 'Speak a past tense verb to add it to the madlib. A past tense verb expresses activity, action, state, or being in the past. What past tense verb would you like?'
        },
        {
          value: null,
          template_key: 'graduation_year',
          prompt: 'the graduation year',
          help: 'speak a verb to add it to the madlib. A verb is a word used to describe an action, state, or occurence and forming the main part of the predicate in a sentence, such as hear, become, happen. What verb would you like?'
        }
      ]
    }
  ];
  for (var prop in obj) this[prop] = obj[prop];
}

MadlibHelper.prototype.completed = function() {
  return this.currentStep === (this.currentMadlib().steps.length - 1);
};

MadlibHelper.prototype.getPrompt = function() {
  return this.getStep().prompt;
};

MadlibHelper.prototype.getStep = function() {
  return this.currentMadlib().steps[this.currentStep];
};

MadlibHelper.prototype.buildMadlib = function() {
  var currentMadlib = this.currentMadlib();
  var templateValues = _.reduce(currentMadlib.steps, function(accumulator, step) {
    accumulator[step.template_key] = step.value;
    return accumulator;
  }, {});
  var compiledTemplate = _.template(currentMadlib.template);
  return compiledTemplate(templateValues);
};


MadlibHelper.prototype.currentMadlib = function() {
  return this.madlibs[this.madlibIndex];
};

module.exports = MadlibHelper;


